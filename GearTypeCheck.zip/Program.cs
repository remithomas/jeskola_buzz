﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using Bartok.MSIL;
using Microsoft.Win32;

namespace GearTypeCheck
{
	class Program
	{
		const int MaxCodeSize = 256;

		struct Pattern
		{
			byte[] bytes;
			int skip;

			public int TotalLength { get { return bytes.Length + skip; } }

			public Pattern(byte[] bytes, int skip)
			{
				this.bytes = bytes;
				this.skip = skip;
			}

			public bool Match(byte[] code, int offset)
			{
				for (int i = 0; i < bytes.Length; i++)
					if (code[offset + i] != bytes[i])
						return false;

				return true;
			}

		}

		static Pattern[] Patterns = 
		{
			new Pattern( new byte [] { 0xE8 }, 4),
			new Pattern( new byte [] { 0x8B, 0xEC }, 0),
			new Pattern( new byte [] { 0x81, 0xEC }, 4),
			new Pattern( new byte [] { 0x53, }, 0),
			new Pattern( new byte [] { 0x55 }, 0),
			new Pattern( new byte [] { 0x56, }, 0),
			new Pattern( new byte [] { 0x57, }, 0),
			new Pattern( new byte [] { 0x8D, 0xBD }, 4),
			new Pattern( new byte [] { 0xB9 }, 4),
			new Pattern( new byte [] { 0xBE }, 4),
			new Pattern( new byte [] { 0xBF }, 4),
			new Pattern( new byte [] { 0xF3, 0xAB }, 0),
			new Pattern( new byte [] { 0xF3, 0xA5 }, 0),
			new Pattern( new byte [] { 0x5F }, 0),
			new Pattern( new byte [] { 0x5E }, 0),
			new Pattern( new byte [] { 0x5B }, 0),
			new Pattern( new byte [] { 0x8B, 0xE5 }, 0),
			new Pattern( new byte [] { 0x5D }, 0)
		};

		static void GetMachineInfoAddressFromGetInfoCode(ref IntPtr result, PELoader pe, int rva, byte[] p)
		{
			if (p == null) return;
			int ofs = 0;

			while (true)
			{
			next:
				for (int i = 0; i < Patterns.Length; i++)
				{
					if (Patterns[i].Match(p, ofs))
					{
						ofs += Patterns[i].TotalLength;
						goto next;
					}
				}

				if (p[ofs] == 0xE9)
				{
					// jump
					var offset = BitConverter.ToInt32(p, ofs + 1) + 5;
					GetMachineInfoAddressFromGetInfoCode(ref result, pe, rva + offset, pe.GetBytesAtRVA(rva + offset, MaxCodeSize));
					return;
				}
				else if (p[ofs] == 0xB8)
				{
					// mov eax, offset MachineInfo
					result = new IntPtr(BitConverter.ToInt32(p, ofs + 1));
					ofs += 5;
				}
				else if (p[ofs] == 0xC3)
				{
					// ret
					return;
				}
				else
				{
					result = IntPtr.Zero;	// no ret instruction
					return;
				}
			}

		}

		[StructLayout(LayoutKind.Sequential)]
		struct RawMachineInfo
		{
			public int Type;
			public int Version;
			public int Flags;
			public int minTracks;
			public int maxTracks;
			public int numGlobalParameters;
			public int numTrackParameters;
			public IntPtr Parameters;
			public int numAttributes;
			public IntPtr Attributes;
			public IntPtr Name;
			public IntPtr ShortName;
			public IntPtr Author;
			public IntPtr Commands;
			//public IntPtr pLI;		// not in old machines so ignore
		}

		static T ByteArrayToStruct<T>(byte[] bytes)
		{
			GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
			T s = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
			handle.Free();
			return s;
		}

		static string ComputeSHA256(string filename)
		{
			var sha256 = new SHA256CryptoServiceProvider();
			return BitConverter.ToString(sha256.ComputeHash(File.ReadAllBytes(filename))).Replace("-", "");
		}

		static void ScanMachineDir(string path, int type)
		{
			foreach (var fn in Directory.EnumerateFiles(path, "*.dll"))
			{
				if (fn.Contains(".GUI.dll")) continue;

				Console.WriteLine(ComputeSHA256(fn));

				int status = 0;

				try
				{
					using (var fs = File.OpenRead(fn))
					{
						var pe = new PELoader(fs, fn);
						var record = pe.ExportRecords != null ? pe.ExportRecords.Where(r => r.name == "GetInfo").First() : null;

						if (record != null)
						{
							var code = pe.GetBytesAtRVA(record.address, MaxCodeSize);

							IntPtr miaddr = IntPtr.Zero;
							GetMachineInfoAddressFromGetInfoCode(ref miaddr, pe, record.address, code);
							if (miaddr != IntPtr.Zero)
							{
								RawMachineInfo s = ByteArrayToStruct<RawMachineInfo>(pe.GetBytesAtRVA(miaddr.ToInt32() - pe.getImageBase(), Marshal.SizeOf(typeof(RawMachineInfo))));
								if (s.Type != type)
								{
									Console.ForegroundColor = ConsoleColor.Yellow;
									status = 1;
								}

							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Magenta;
								status = 2;
							}

						}

					}

					Console.WriteLine(status + " " + fn);

				}
				catch (Exception e)
				{
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("3 " + fn);
					//Console.WriteLine(e);
					Console.ForegroundColor = ConsoleColor.Gray;
				}

				Console.ForegroundColor = ConsoleColor.Gray;
			}
		}

		static void Main(string[] args)
		{
			var key = Registry.CurrentUser.OpenSubKey("Software\\Jeskola\\Buzz\\Settings");
			if (key == null) return;

			var buzzpath = key.GetValue("BuzzPath") as string;
			if (buzzpath == null) return;

			Console.WriteLine("Error Codes:");

			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.WriteLine("1: CMachineInfo::Type / directory mismatch");

			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine("2: Could not extract machine info");

			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("3: Could not load dll (upx compressed?)");

			Console.ForegroundColor = ConsoleColor.Gray;
			Console.WriteLine("--------------------------------------------------");
			
			ScanMachineDir(Path.Combine(buzzpath, "Gear\\Generators"), 1);
			ScanMachineDir(Path.Combine(buzzpath, "Gear\\Effects"), 2);

		}

	}
}
